export const PAD = Object.freeze({
  ANALOG_LEFT_X: 0, ANALOG_LEFT_Y: 1, ANALOG_RIGHT_X: 2, ANALOG_RIGHT_Y: 3,
  DPAD_UP: 4, DPAD_DOWN: 5, DPAD_LEFT: 6, DPAD_RIGHT: 7,
  SELECT: 8, START: 9, SQUARE: 10, TRIANGLE: 11, CIRCLE: 12, CROSS: 13,
  L1: 14, L2: 15, L3: 16, R1: 17, R2: 18, R3: 19,
});

export const KEY = Object.freeze({
  SQUARE: 'KeyA', CROSS: 'KeyZ', TRIANGLE: 'KeyS', CIRCLE: 'KeyX',
  L1: 'Key1', L2: 'Key2', L3: 'Key3', R1: 'Key8', R2: 'Key9', R3: 'Key0',
  START: 'Enter', SELECT: 'Backspace',
  LEFT_LEFT: 'KeyF', LEFT_RIGHT: 'KeyH', LEFT_UP: 'KeyT', LEFT_DOWN: 'KeyG',
  RIGHT_LEFT: 'KeyJ', RIGHT_RIGHT: 'KeyL', RIGHT_UP: 'KeyI', RIGHT_DOWN: 'KeyK',
});

export const KEY_TO_PAD = Object.freeze({
  [KEY.SQUARE]: PAD.SQUARE, [KEY.CROSS]: PAD.CROSS, [KEY.TRIANGLE]: PAD.TRIANGLE, [KEY.CIRCLE]: PAD.CIRCLE,
  [KEY.L1]: PAD.L1, [KEY.L2]: PAD.L2, [KEY.L3]: PAD.L3, [KEY.R1]: PAD.R1, [KEY.R2]: PAD.R2, [KEY.R3]: PAD.R3,
  [KEY.START]: PAD.START, [KEY.SELECT]: PAD.SELECT,
});

export const CONTROL_PROFILES = Object.freeze({
  onFootMitch: [
    ['ATTACK/FIRE', KEY.SQUARE], ['ACTION', KEY.TRIANGLE], ['COVER/ROLL', KEY.CROSS], ['ARREST/DRAG', KEY.CIRCLE],
    ['TARGET', KEY.R1], ['FREE AIM', KEY.R2], ['RELOAD', KEY.L2], ['WEAPON', KEY.R3],
  ],
  driving: [
    ['ACCEL', KEY.CROSS], ['BRAKE', KEY.SQUARE], ['REVERSE', KEY.CIRCLE], ['EXIT', KEY.TRIANGLE],
    ['HANDBRAKE', KEY.R1], ['SHOOT', KEY.L1], ['LOOK L', KEY.L2], ['LOOK R', KEY.R2],
  ],
});
