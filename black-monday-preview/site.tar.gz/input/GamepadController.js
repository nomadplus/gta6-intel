import { KEY, PAD } from './controlProfiles.js';
import { axisToPs2Byte, vectorToDigitalKeys } from './inputMath.js';

// W3C Standard Gamepad layout -> PS2 pad semantics used by Play!.
const BUTTON_MAP = Object.freeze({
  0: [PAD.CROSS, KEY.CROSS],
  1: [PAD.CIRCLE, KEY.CIRCLE],
  2: [PAD.SQUARE, KEY.SQUARE],
  3: [PAD.TRIANGLE, KEY.TRIANGLE],
  4: [PAD.L1, KEY.L1],
  5: [PAD.R1, KEY.R1],
  6: [PAD.L2, KEY.L2],
  7: [PAD.R2, KEY.R2],
  8: [PAD.SELECT, KEY.SELECT],
  9: [PAD.START, KEY.START],
  10: [PAD.L3, KEY.L3],
  11: [PAD.R3, KEY.R3],
});

const DPAD_MAP = Object.freeze({
  12: [PAD.DPAD_UP, 'ArrowUp'],
  13: [PAD.DPAD_DOWN, 'ArrowDown'],
  14: [PAD.DPAD_LEFT, 'ArrowLeft'],
  15: [PAD.DPAD_RIGHT, 'ArrowRight'],
});

export class GamepadController {
  constructor({ canvas, emitKey, onActivity = () => {} } = {}) {
    this.canvas = canvas;
    this.emitKey = emitKey ?? ((code, down) => this.dispatchKey(code, down));
    this.onActivity = onActivity;
    this.nativePadSink = null;
    this.running = false;
    this.raf = 0;
    this.heldKeys = new Set();
    this.lastPadIndex = null;
    this.axisDeadzone = 0.12;
    this._loop = this._loop.bind(this);
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.raf = requestAnimationFrame(this._loop);
  }

  stop() {
    this.running = false;
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.releaseAll();
  }

  attachNativePadSink({ setValue, clearValue, clearAll }) {
    this.releaseAll();
    this.nativePadSink = { setValue, clearValue, clearAll };
    this.nativePadSink.clearAll?.();
  }

  detachNativePadSink() {
    this.releaseAll();
    this.nativePadSink = null;
  }

  _loop() {
    if (!this.running) return;
    const pads = navigator.getGamepads?.() ?? [];
    const pad = [...pads].find(p => p && p.connected && (p.mapping === 'standard' || p.axes.length >= 4));
    if (pad) this.updateFromGamepad(pad);
    else if (this.lastPadIndex !== null) {
      this.releaseAll();
      this.lastPadIndex = null;
    }
    this.raf = requestAnimationFrame(this._loop);
  }

  updateFromGamepad(gamepad) {
    this.lastPadIndex = gamepad.index;
    const buttonStates = Object.fromEntries(
      [...Object.keys(BUTTON_MAP), ...Object.keys(DPAD_MAP)].map(indexText => {
        const index = Number(indexText);
        const button = gamepad.buttons[index];
        return [index, Boolean(button?.pressed || (button?.value ?? 0) > 0.5)];
      }),
    );
    const axes = [0, 1, 2, 3].map(i => this.applyDeadzone(gamepad.axes[i] ?? 0));
    const active = Object.values(buttonStates).some(Boolean) || axes.some(v => Math.abs(v) > 0);

    // Claim ownership before emitting the first active frame so a newly used gamepad
    // doesn't lose its first movement/button event to the input arbiter.
    if (active) this.onActivity({ type: 'gamepad', index: gamepad.index, id: gamepad.id });

    for (const [indexText, [padButton, fallbackKey]] of Object.entries(BUTTON_MAP)) {
      this.emitButton(padButton, fallbackKey, buttonStates[Number(indexText)]);
    }
    for (const [indexText, [padButton, fallbackKey]] of Object.entries(DPAD_MAP)) {
      this.emitButton(padButton, fallbackKey, buttonStates[Number(indexText)]);
    }

    if (this.nativePadSink) {
      this.nativePadSink.setValue(PAD.ANALOG_LEFT_X, axisToPs2Byte(axes[0]));
      this.nativePadSink.setValue(PAD.ANALOG_LEFT_Y, axisToPs2Byte(axes[1]));
      this.nativePadSink.setValue(PAD.ANALOG_RIGHT_X, axisToPs2Byte(axes[2]));
      this.nativePadSink.setValue(PAD.ANALOG_RIGHT_Y, axisToPs2Byte(axes[3]));
    } else {
      this.syncKeyGroup(
        vectorToDigitalKeys(axes[0], axes[1], { left: KEY.LEFT_LEFT, right: KEY.LEFT_RIGHT, up: KEY.LEFT_UP, down: KEY.LEFT_DOWN }, 0.25),
        [KEY.LEFT_LEFT, KEY.LEFT_RIGHT, KEY.LEFT_UP, KEY.LEFT_DOWN],
      );
      this.syncKeyGroup(
        vectorToDigitalKeys(axes[2], axes[3], { left: KEY.RIGHT_LEFT, right: KEY.RIGHT_RIGHT, up: KEY.RIGHT_UP, down: KEY.RIGHT_DOWN }, 0.25),
        [KEY.RIGHT_LEFT, KEY.RIGHT_RIGHT, KEY.RIGHT_UP, KEY.RIGHT_DOWN],
      );
    }
  }

  applyDeadzone(value) {
    const v = Number.isFinite(value) ? Math.max(-1, Math.min(1, value)) : 0;
    if (Math.abs(v) <= this.axisDeadzone) return 0;
    const sign = Math.sign(v);
    return sign * ((Math.abs(v) - this.axisDeadzone) / (1 - this.axisDeadzone));
  }

  emitButton(padButton, fallbackKey, down) {
    if (this.nativePadSink) {
      if (down) this.nativePadSink.setValue(padButton, 1);
      else this.nativePadSink.clearValue(padButton);
    } else this.setFallbackKey(fallbackKey, down);
  }

  syncKeyGroup(next, group) {
    for (const code of group) this.setFallbackKey(code, next.has(code));
  }

  setFallbackKey(code, down) {
    const already = this.heldKeys.has(code);
    if (already === down) return;
    if (down) this.heldKeys.add(code); else this.heldKeys.delete(code);
    this.emitKey(code, down);
  }

  neutralizeAxes() {
    if (!this.nativePadSink) return;
    const neutral = axisToPs2Byte(0);
    this.nativePadSink.setValue(PAD.ANALOG_LEFT_X, neutral);
    this.nativePadSink.setValue(PAD.ANALOG_LEFT_Y, neutral);
    this.nativePadSink.setValue(PAD.ANALOG_RIGHT_X, neutral);
    this.nativePadSink.setValue(PAD.ANALOG_RIGHT_Y, neutral);
  }

  releaseAll() {
    for (const code of [...this.heldKeys]) this.setFallbackKey(code, false);
    this.nativePadSink?.clearAll?.();
  }

  dispatchKey(code, down) {
    const event = new KeyboardEvent(down ? 'keydown' : 'keyup', { code, bubbles: true, cancelable: true });
    this.canvas?.dispatchEvent(event);
  }
}

export const STANDARD_GAMEPAD_BUTTON_MAP = BUTTON_MAP;
